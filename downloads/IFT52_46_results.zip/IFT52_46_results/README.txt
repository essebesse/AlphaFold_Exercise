AlphaFold3 result for Part 2, full-length IFT52 + IFT46 job, for use if the AlphaFold3 server is not working.

fold_crift52_46_model_0.cif                 The top-ranked model. Chain A = IFT52, chain B = IFT46.
fold_crift52_46_summary_confidences_0.json  Its scores; open in a text editor and look for "iptm" and "ptm".
PAE_IFT52_46.png                            The PAE plot, in place of the server's viewer. Residue numbers of each chain are on the axes.
fold_crift52_46_full_data_0.json            The full PAE matrix, only needed for the optional Python tasks.

Continue from Section 3 of the exercise.
