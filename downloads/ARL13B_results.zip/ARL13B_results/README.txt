AlphaFold3 results for Part 1 (ARL13B), for use if the AlphaFold3 server is not working.

These are the same files the server would give you, so follow the exercise as written:

ARL13B_apo/   Job 1, ARL13B alone. Five models (*_model_0.cif to *_model_4.cif) and their scores (*_summary_confidences_*.json; open in a text editor and look for "ptm").
ARL13B_GTP/   Job 2, ARL13B + GTP + Mg2+. Same layout. Chain A = protein, B = GTP, C = Mg2+.
PAE_ARL13B_GTP_Mg.png   The PAE plot for the GTP job (for the optional PAE section), in place of the server's viewer.

In PyMOL: drag the .cif files into the window, then continue from Section 6 of the exercise.
