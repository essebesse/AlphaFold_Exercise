AlphaFold3 result for Part 2, truncated (minimal) IFT52 + IFT46 job, for use if the AlphaFold3 server is not working. Only open this after you have chosen your own residue ranges in Section 5.

This job used IFT52 residues 350-455 and IFT46 residues 180-344.

fold_hs52_46_minimal_model_0.cif                 The top-ranked model. Chain A = IFT52 fragment, chain B = IFT46 fragment. Note: AlphaFold numbers each fragment from 1, so residue 1 in chain A is IFT52 residue 350, and residue 1 in chain B is IFT46 residue 180.
fold_hs52_46_minimal_summary_confidences_0.json  Its scores; look for "iptm" and "ptm".
PAE_IFT52_46_trunc.png                           The PAE plot, with the axes labelled in full-length residue numbers.
fold_hs52_46_minimal_full_data_0.json            The full PAE matrix, only needed for the optional Python tasks.
4uzz.pdb                                         The experimental crystal structure for Section 6. In PyMOL use "load 4uzz.pdb" instead of "fetch 4uzz".
